FB.api('/me', function(response) {
       console.log(response.email);
});