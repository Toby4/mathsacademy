<?php include("inc/header.php"); ?>

<h1>Logging in..</h1>

<META HTTP-EQUIV="refresh" CONTENT="0;URL=index.php">

<?php include("inc/footer.php"); ?>