<?php include("inc/header.php");
?>        
</div>

 <section class = "section" id="box1">
            <h1 class = 'title_h1'>courses</h1>
            <a href = "#">Algebra</a>
            <a href = "#">Algebra</a>
            <a href = "#">Algebra</a>
            <br />
             <a href = "#">Algebra</a>
             <a href = "#">Algebra</a>
             <a href = "#">Algebra</a>
            <br />
             <a href = "#">Algebra</a>
             <a href = "#">Algebra</a>
             <a href = "#">Algebra</a>
            </div>
            </section>