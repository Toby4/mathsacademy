firebase-php
============

[![Build Status](https://drone.io/github.com/ktamas77/firebase-php/status.png)](https://drone.io/github.com/ktamas77/firebase-php/latest)

Firebase PHP Client

Based on Firebase REST API: https://www.firebase.com/docs/rest-api.html

Base library: @ktamas77
Token auth: @craigrusso
Update & Push method: @mintao
